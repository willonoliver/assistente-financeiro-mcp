# FinAssist — Assistente Financeiro com MCP

Projeto educacional para o desafio **“Levando o Banco para Onde o Cliente Já Está: Um Agente Financeiro com MCP”**, da DIO.

O FinAssist é uma aplicação web em formato de chat, com painel de contas, saldos e transações. Esta versão inicial roda localmente com **dados fictícios** e contém uma interface pronta para evoluir com um backend que consulte ferramentas MCP da Pluggy e da Plaid.

> **Importante:** a interface atual é uma demonstração. Ela ainda não consulta contas bancárias reais nem está conectada à Pluggy ou à Plaid. Não insira credenciais bancárias ou chaves reais no frontend.

## 1. Tecnologias

- React
- TypeScript
- Vite
- Lucide React
- CSS responsivo

A estrutura foi escolhida para permitir abrir o mesmo repositório no Visual Studio Code e importá-lo no Lovable como projeto React/Vite.

## 2. O que já está implementado

- Dashboard financeiro responsivo.
- Cartões de resumo de saldo, dívida demonstrativa e quantidade de transações.
- Lista de contas e cartões.
- Histórico de transações de exemplo.
- Chat com respostas locais para perguntas sobre saldo, gastos, transações e cartão.
- Aviso visível de que os dados são fictícios.
- `.gitignore` para evitar versionamento de arquivos locais e credenciais.

## 3. Executar no Visual Studio Code

Pré-requisitos:
- Node.js LTS instalado.
- npm (incluído com Node.js).
- Visual Studio Code.

Passos:

```bash
# 1. Extraia o ZIP e abra a pasta no VS Code
# 2. No terminal, dentro da pasta do projeto:
npm install

# 3. Inicie o servidor de desenvolvimento
npm run dev
```

O Vite mostrará um endereço local, normalmente `http://localhost:5173`.

Para validar a compilação:

```bash
npm run build
npm run preview
```

## 4. Abrir no Lovable

O caminho mais simples é usar o GitHub como ponte:

1. Crie um repositório público ou privado na sua conta do GitHub.
2. Extraia o ZIP e envie os arquivos do projeto para esse repositório.
3. No Lovable, escolha a opção de importar/conectar um projeto GitHub e selecione o repositório.
4. Aguarde a importação e peça alterações pelo chat do Lovable.
5. Revise os arquivos alterados e teste a aplicação.

O Lovable pode ajustar a interface e os componentes. Se ele alterar dependências ou scripts, valide novamente com `npm install` e `npm run build`.

## 5. Estrutura de pastas

```text
assistente-financeiro-mcp/
├── src/
│   ├── data/
│   │   └── demo.ts          # Contas e transações fictícias
│   ├── App.tsx               # Dashboard e chat
│   ├── main.tsx              # Inicialização React
│   └── styles.css            # Estilos responsivos
├── .env.example              # Exemplo de variável pública não sensível
├── .gitignore
├── index.html
├── package.json
├── tsconfig.app.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

## 6. Integração MCP: arquitetura recomendada

A arquitetura final deve separar a interface web das credenciais e das conexões com provedores:

```text
Navegador (React / Lovable)
        |
        | HTTPS - API da aplicação
        v
Backend seguro (Node.js ou outro runtime)
        |
        | Cliente MCP
        +--------------------+
        |                    |
        v                    v
MCP Pluggy              MCP Plaid
Documentação e          Sandbox com dados
integração brasileira   financeiros fictícios
```

**Não conecte o navegador diretamente a servidores MCP que exigem segredos.** O backend deve controlar as credenciais, validar a identidade/permissões do usuário, chamar as ferramentas MCP e devolver somente os dados necessários ao frontend.

### Pluggy

Endpoint MCP informado no material do desafio:

```text
https://mcp.pluggy.ai/mcp
```

O guia da aula orienta adicionar a conexão nas configurações MCP da ferramenta de IA utilizada pelo desenvolvedor. Consulte a documentação oficial da Pluggy para confirmar transporte, autenticação e ferramentas disponíveis antes de implementar o cliente.

### Plaid Sandbox

A Plaid Sandbox fornece dados de teste. O material do desafio orienta configurar o servidor `mcp-server-plaid` por STDIO, usando `uv`/`uvx` e as credenciais Sandbox.

As credenciais devem existir somente no ambiente seguro do backend ou na configuração local privada do servidor MCP. Nunca as coloque em `src/`, em variáveis `VITE_*`, no README ou em commits.

## 7. Variáveis de ambiente

O arquivo `.env.example` contém somente um exemplo de URL da API. Para uso local, copie-o:

```bash
cp .env.example .env
```

No Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Variáveis com prefixo `VITE_` são incorporadas ao bundle do navegador e **não podem conter segredos**. Não adicione `PLAID_CLIENT_SECRET`, `PLUGGY_CLIENT_SECRET`, tokens ou senhas a variáveis `VITE_*`.

## 8. Próximas etapas recomendadas

1. Criar um backend seguro para a aplicação.
2. Configurar o servidor MCP da Plaid em Sandbox e validar a leitura de contas, saldos e transações.
3. Conectar a Pluggy e consultar sua documentação/ferramentas disponíveis.
4. Criar endpoints próprios no backend, por exemplo:
   - `GET /api/accounts`
   - `GET /api/balances`
   - `GET /api/transactions`
   - `POST /api/chat`
5. Substituir os dados de `src/data/demo.ts` por respostas do backend.
6. Fazer o assistente responder somente com dados retornados pelas ferramentas autorizadas.
7. Tratar erros, indisponibilidade, consentimento e limites de acesso.
8. Adicionar testes e publicar a aplicação.

## 9. Cuidados com valores e dados financeiros

- Na Plaid, conforme o enunciado do desafio, valor positivo em transações representa saída. Confirme o significado de cada campo retornado pela ferramenta antes de exibir ou somar valores.
- Saldo negativo de cartão pode representar dívida, não dinheiro disponível.
- Informe moeda, período e origem dos dados.
- Identifique claramente dados de Sandbox como fictícios.
- Não apresente a demonstração como integração bancária real.
- Não solicite nem armazene senhas bancárias do usuário.

## 10. Segurança antes de publicar

- [ ] Nenhuma chave, token ou senha está no código frontend.
- [ ] Arquivos `.env` estão ignorados pelo Git.
- [ ] O backend não expõe segredos em respostas ou logs.
- [ ] O aplicativo avisa que os dados de demonstração são fictícios.
- [ ] O README descreve corretamente o que está implementado e o que ainda falta.
- [ ] A compilação `npm run build` termina sem erros.

## 11. Publicação

Para publicar, conecte o repositório GitHub a uma plataforma compatível com Vite/React (por exemplo, a publicação do Lovable ou outro host estático). Configure a URL do backend conforme o ambiente de produção. O frontend estático sozinho não substitui o backend necessário para guardar segredos e acessar serviços MCP.

---

**Status do projeto:** protótipo inicial de interface concluído; integrações MCP e backend seguro são etapas futuras.

**Objetivo acadêmico:** demonstrar o fluxo de uma pergunta financeira até a consulta de ferramentas e a apresentação da resposta em linguagem simples.
