import { useMemo, useState } from "react";
import { ArrowDownLeft, ArrowUpRight, Bot, CreditCard, Landmark, Send, ShieldCheck, Sparkles, Wallet } from "lucide-react";
import { accounts, transactions } from "./data/demo";

type Message = { role: "assistant" | "user"; text: string };

const money = (value: number) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function answerQuestion(question: string): string {
  const q = question.toLocaleLowerCase("pt-BR");
  const total = accounts.filter(a => a.balance > 0).reduce((sum, a) => sum + a.balance, 0);
  const expenses = transactions.filter(t => t.amount < 0).reduce((sum, t) => sum + Math.abs(t.amount), 0);

  if (q.includes("saldo") || q.includes("quanto tenho")) {
    return `Nos dados demonstrativos, você possui ${money(total)} em saldos positivos. O cartão apresenta ${money(Math.abs(accounts[1].balance))} em dívida.`;
  }
  if (q.includes("gasto") || q.includes("despesa")) {
    return `Considerando as transações de exemplo exibidas, as despesas somam ${money(expenses)}. Isso é apenas uma amostra fictícia, não um extrato bancário real.`;
  }
  if (q.includes("transa") || q.includes("compra")) {
    return `Encontrei ${transactions.length} transações demonstrativas. As maiores despesas da amostra são Mercado Central (${money(245.80)}) e Posto Avenida (${money(180)}).`;
  }
  if (q.includes("cartão") || q.includes("cartao") || q.includes("dívida") || q.includes("divida")) {
    return `O cartão de crédito aparece com saldo devedor de ${money(Math.abs(accounts[1].balance))}. Neste painel, valores negativos representam dívida ou saída, não dinheiro disponível.`;
  }
  return "Posso ajudar a consultar saldos, entender transações e resumir gastos por categoria. Os dados atuais são fictícios. Quando a integração com o backend MCP estiver configurada, as respostas poderão usar dados autorizados da fonte financeira.";
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", text: "Olá! Sou seu assistente financeiro. Posso ajudar a entender saldos, contas e transações. Esta versão está em modo de demonstração, com dados fictícios." }
  ]);
  const [draft, setDraft] = useState("");
  const [showAll, setShowAll] = useState(false);

  const totalAvailable = useMemo(
    () => accounts.filter(a => a.balance > 0).reduce((sum, a) => sum + a.balance, 0),
    []
  );
  const displayedTransactions = showAll ? transactions : transactions.slice(0, 4);

  function sendMessage(text = draft) {
    const clean = text.trim();
    if (!clean) return;
    setMessages(current => [
      ...current,
      { role: "user", text: clean },
      { role: "assistant", text: answerQuestion(clean) }
    ]);
    setDraft("");
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark"><Wallet size={21} /></div><div><strong>FinAssist</strong><span>Seu copiloto financeiro</span></div></div>
        <div className="side-label">VISÃO GERAL</div>
        <a className="nav-item active"><Landmark size={17} /> Painel financeiro</a>
        <a className="nav-item"><CreditCard size={17} /> Contas e cartões</a>
        <a className="nav-item"><ArrowUpRight size={17} /> Transações</a>
        <div className="sidebar-bottom">
          <div className="secure-note"><ShieldCheck size={17} /><span><b>Ambiente demonstrativo</b><small>Nenhuma conta bancária real conectada.</small></span></div>
          <div className="profile"><div className="avatar">U</div><div><b>Usuário</b><small>Conta de demonstração</small></div></div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar"><div><span className="eyebrow">QUARTA-FEIRA, 18 DE NOVEMBRO DE 2026</span><h1>Visão geral</h1></div><div className="demo-pill"><span /> Dados fictícios</div></header>

        <section className="welcome-row">
          <div><h2>Olá! Como estão suas finanças?</h2><p>Acompanhe suas contas e converse com seu assistente financeiro.</p></div>
          <div className="welcome-icon"><Sparkles size={25} /></div>
        </section>

        <section className="metrics-grid">
          <article className="metric-card"><div className="metric-head"><span>Saldo positivo total</span><div className="metric-icon green"><Wallet size={18} /></div></div><strong>{money(totalAvailable)}</strong><small>Somatório das contas com saldo positivo</small></article>
          <article className="metric-card"><div className="metric-head"><span>Fatura / dívida do cartão</span><div className="metric-icon orange"><CreditCard size={18} /></div></div><strong>{money(Math.abs(accounts[1].balance))}</strong><small>Valor devedor demonstrativo</small></article>
          <article className="metric-card"><div className="metric-head"><span>Transações de exemplo</span><div className="metric-icon blue"><ArrowUpRight size={18} /></div></div><strong>{transactions.length}</strong><small>Registros fictícios disponíveis</small></article>
        </section>

        <section className="content-grid">
          <div className="panel accounts-panel">
            <div className="panel-title"><div><h3>Suas contas</h3><p>Visão resumida das fontes financeiras</p></div><Landmark size={19} /></div>
            <div className="account-list">
              {accounts.map(account => <div className="account-row" key={account.id}><div className="bank-icon"><Landmark size={18} /></div><div className="account-info"><b>{account.name}</b><span>{account.institution} · final {account.lastFour}</span></div><div className="account-balance"><b className={account.balance < 0 ? "negative" : ""}>{money(Math.abs(account.balance))}</b><span>{account.balance < 0 ? "Valor devedor" : account.type}</span></div></div>)}
            </div>
          </div>

          <div className="panel transactions-panel">
            <div className="panel-title"><div><h3>Transações recentes</h3><p>Movimentações fictícias</p></div><ArrowUpRight size={19} /></div>
            <div className="transaction-list">
              {displayedTransactions.map(t => <div className="transaction-row" key={t.id}><div className={`transaction-icon ${t.amount > 0 ? "income" : ""}`}>{t.amount > 0 ? <ArrowDownLeft size={17} /> : <ArrowUpRight size={17} />}</div><div className="transaction-info"><b>{t.name}</b><span>{t.category} · {new Date(`${t.date}T12:00:00`).toLocaleDateString("pt-BR")}</span></div><strong className={t.amount > 0 ? "positive" : ""}>{t.amount > 0 ? "+" : "−"}{money(Math.abs(t.amount))}</strong></div>)}
            </div>
            <button className="text-button" onClick={() => setShowAll(v => !v)}>{showAll ? "Mostrar menos" : "Ver todas as transações"}</button>
          </div>
        </section>

        <section className="chat-panel">
          <div className="chat-heading"><div className="bot-avatar"><Bot size={21} /></div><div><h3>Converse com seu assistente</h3><p>Faça perguntas sobre suas finanças</p></div><span className="online-status">Demonstração</span></div>
          <div className="chat-messages">
            {messages.map((message, index) => <div className={`message ${message.role}`} key={index}><div className="message-avatar">{message.role === "assistant" ? <Bot size={16} /> : "U"}</div><div className="message-bubble">{message.text}</div></div>)}
          </div>
          <div className="suggestions"><button onClick={() => sendMessage("Qual é o meu saldo?")}>Qual é o meu saldo?</button><button onClick={() => sendMessage("Quanto gastei?")}>Quanto gastei?</button><button onClick={() => sendMessage("Mostre minhas transações")}>Minhas transações</button></div>
          <form className="chat-input" onSubmit={e => { e.preventDefault(); sendMessage(); }}><input value={draft} onChange={e => setDraft(e.target.value)} placeholder="Pergunte algo sobre suas finanças..." /><button type="submit" aria-label="Enviar mensagem" disabled={!draft.trim()}><Send size={18} /></button></form>
          <p className="disclaimer">Respostas desta versão usam dados locais fictícios. Não são aconselhamento financeiro.</p>
        </section>
        <footer>FinAssist · Projeto educacional DIO · Integração MCP a configurar</footer>
      </main>
    </div>
  );
}
