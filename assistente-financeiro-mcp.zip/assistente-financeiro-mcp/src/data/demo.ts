export type Account = {
  id: string;
  name: string;
  institution: string;
  type: string;
  balance: number;
  lastFour: string;
};

export type Transaction = {
  id: string;
  name: string;
  category: string;
  date: string;
  amount: number;
  account: string;
};

export const accounts: Account[] = [
  { id: "acc-1", name: "Conta corrente", institution: "Banco de demonstração", type: "Corrente", balance: 8420.50, lastFour: "4821" },
  { id: "acc-2", name: "Cartão de crédito", institution: "Cartão de demonstração", type: "Crédito", balance: -1280.75, lastFour: "9012" },
  { id: "acc-3", name: "Poupança", institution: "Banco de demonstração", type: "Poupança", balance: 3200.00, lastFour: "1138" }
];

export const transactions: Transaction[] = [
  { id: "t-1", name: "Mercado Central", category: "Alimentação", date: "2026-11-16", amount: -245.80, account: "Conta corrente" },
  { id: "t-2", name: "Salário", category: "Renda", date: "2026-11-15", amount: 4200.00, account: "Conta corrente" },
  { id: "t-3", name: "Posto Avenida", category: "Transporte", date: "2026-11-14", amount: -180.00, account: "Cartão de crédito" },
  { id: "t-4", name: "Streaming", category: "Assinaturas", date: "2026-11-13", amount: -39.90, account: "Cartão de crédito" },
  { id: "t-5", name: "Farmácia", category: "Saúde", date: "2026-11-12", amount: -86.40, account: "Conta corrente" },
  { id: "t-6", name: "Restaurante", category: "Alimentação", date: "2026-11-10", amount: -92.00, account: "Cartão de crédito" }
];
